import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Hashtable;


public class Table {
	
	ArrayList<FileWriter> records;
	
	public Table() {
		// TODO Auto-generated constructor stub
	}
	
	public Table(String strTableName,
			Hashtable<String,String> htblColNameType,
			Hashtable<String,String>htblColNameRefs,
			String strKeyColName) throws DBAppException  {
		
		
	}
	
	
	

}

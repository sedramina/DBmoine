
import java.util.Enumeration;
import java.util.Hashtable;
import java.io.*;

public class DBApp {
	
	File metadata;
	BufferedWriter bfw;
	BufferedReader bfr;
	
	public DBApp() throws DBAppException, IOException {
		// TODO Auto-generated constructor stub
		this.metadata = new File("C:\\Users\\Ahmed\\Univeristy\\Databases 2\\data\\metadata.csv");
		metadata.createNewFile();
		FileWriter temp = new FileWriter(metadata);
        bfw = new BufferedWriter(temp);
        bfw.write("TableName");
		bfw.write(",");
		bfw.write("ColoumnName");
		bfw.write(",");
		bfw.write("ColoumnType");
		bfw.write(",");
		bfw.write("Key");
		bfw.write(",");
		bfw.write("Indexed");
		bfw.write(",");
		bfw.write("Refrenced");
		bfw.newLine();
		bfw.flush();
		bfw.close();
	}
	
	public void createTable(String strTableName,
			Hashtable<String,String> htblColNameType,
			Hashtable<String,String>htblColNameRefs,
			String strKeyColName)
			throws DBAppException, IOException{
		
		
		this.bfw = new BufferedWriter(new FileWriter(metadata, true));
		
		Enumeration<String> htb1 = htblColNameType.keys();
		
		String temp;
		
		
		while(htb1.hasMoreElements()){
			temp = (String) htb1.nextElement();
			if(strKeyColName.equals(temp)) {
				bfw.write(strTableName);
				bfw.write(",");
				bfw.write(" " + temp);
				bfw.write(",");
				bfw.write(" " + htblColNameType.get(temp));
				bfw.write(",");
				bfw.write(" True");
				bfw.write(",");
				bfw.write(" True");
				bfw.write(",");
				bfw.write(" " + htblColNameRefs.get(temp));
				bfw.newLine();
			}
			else {
				bfw.write(strTableName);
				bfw.write(",");
				bfw.write(" " + temp);
				bfw.write(",");
				bfw.write(" " + htblColNameType.get(temp));
				bfw.write(",");
				bfw.write(" False");
				bfw.write(",");
				bfw.write(" False");
				bfw.write(",");
				bfw.write(" " +htblColNameRefs.get(temp));
				bfw.newLine();
				
			}			
		}
		bfw.flush();
		bfw.close();
				
	}
	
	public static void main(String[] args) throws DBAppException, IOException {
		Hashtable<String, String> ht = new Hashtable<String,String>();
		ht.put("Name", "String");
		ht.put("ID", "int");
		
		Hashtable<String, String> rf = new Hashtable<String,String>();
		rf.put("Name", "Dept");
		String name = "Employee";
		String Key = "ID";
		
		Hashtable<String, String> dht = new Hashtable<String,String>();
		dht.put("Dep Name", "String");
		dht.put("Company", "String");
		
		Hashtable<String, String> drf = new Hashtable<String,String>();
		drf.put("Name", "Dept");
		String nameOfDep = "Dep";
		String KeyOfDep = "Dep Name";
		
		DBApp x = new DBApp();
		x.createTable(name, ht, rf, Key);
		x.createTable(nameOfDep, dht, drf, KeyOfDep);
		/*x.bfw.write("hello world!");
		x.bfw.flush();
		x.bfw.close();
		
		FileReader temp = new FileReader(x.metadata);
		x.bfr = new BufferedReader(temp);
		System.out.println(x.bfr.readLine());
		x.bfr.readLine();
		x.bfr.readLine();
		x.bfr.close();
		x.bfw = new BufferedWriter(new FileWriter(x.metadata, true));
		x.bfw.newLine();
		x.bfw.write("ya rab");
		x.bfr.
		x.bfw.close();
		*/
		
				
		
	}

}


import java.util.Enumeration;
import java.util.Hashtable;
import java.io.*;

public class DBApp {
	
	FileWriter metadata;
	PrintWriter pw;
	
	public DBApp() throws DBAppException, IOException {
		// TODO Auto-generated constructor stub
		this.metadata = new FileWriter("C:\\Users\\Ahmed\\Univeristy\\Databases 2\\data\\metadata.csv");
        pw = new PrintWriter(metadata);
        pw.print("TableName");
		pw.print(",");
		pw.print("ColoumnName");
		pw.print(",");
		pw.print("ColoumnType");
		pw.print(",");
		pw.print("Key");
		pw.print(",");
		pw.print("Indexed");
		pw.print(",");
		pw.println("Refrenced");
	}
	
	public void createTable(String strTableName,
			Hashtable<String,String> htblColNameType,
			Hashtable<String,String>htblColNameRefs,
			String strKeyColName)
			throws DBAppException{
		
		
		
		Enumeration<String> htb1 = htblColNameType.keys();
		
		String temp;
		this.pw = new PrintWriter(this.metadata);
		
		while(htb1.hasMoreElements()){
			temp = (String) htb1.nextElement();
			if(strKeyColName.equals(temp)) {
				pw.print(strTableName);
				pw.print(",");
				pw.print(" " + temp);
				pw.print(",");
				pw.print(" " + htblColNameType.get(temp));
				pw.print(",");
				pw.print(" True");
				pw.print(",");
				pw.print(" True");
				pw.print(",");
				pw.println(" " + htblColNameRefs.get(temp));
			}
			else {
				pw.print(strTableName);
				pw.print(",");
				pw.print(" " + temp);
				pw.print(",");
				pw.print(" " + htblColNameType.get(temp));
				pw.print(",");
				pw.print(" False");
				pw.print(",");
				pw.print(" False");
				pw.print(",");
				pw.println(" " +htblColNameRefs.get(temp));
				
			}			
		}
				
	}
	
	public static void main(String[] args) throws DBAppException, IOException {
		Hashtable<String, String> ht = new Hashtable<String,String>();
		ht.put("Name", "String");
		ht.put("ID", "int");
		
		Hashtable<String, String> rf = new Hashtable<String,String>();
		rf.put("Name", "Dept");
		String name = "Employee";
		String Key = "ID";
		
		DBApp x = new DBApp();
		x.createTable(name, ht, rf, Key);
		x.pw.flush();
        x.pw.close();
				
		
	}

}

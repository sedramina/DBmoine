import java.io.IOException;


public class DBAppException extends IOException {
	
	public DBAppException() {
		// TODO Auto-generated constructor stub
	}
}

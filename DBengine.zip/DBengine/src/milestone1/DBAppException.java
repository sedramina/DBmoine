package milestone1;

public class DBAppException extends Exception {

}